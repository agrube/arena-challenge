To Build:
Install Java 16 and Maven 3.8
In the root directory, run "mvn install"

To Run:
In the target directory, verify that arena-1.0-SNAPSHOT.jar was built.
Run the following command:
	
	java -jar .\arena-1.0-SNAPSHOT.jar <path to artists file>